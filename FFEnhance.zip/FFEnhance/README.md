# FF Enhance (Android project)

Screen-enhancer overlay for Free Fire: captures only the game window (Android 14+ "share one app"),
runs an adaptive-sharpen / contrast / saturation GLSL shader, and shows it as a touch-through overlay.

## Build the APK
**Option A – no PC (GitHub):** create a repo, upload everything in this folder (keep `.github`),
open the Actions tab -> "Build APK" -> download artifact `FFEnhance-apk` (app-debug.apk).

**Option B – Android Studio:** File > Open this folder, wait for sync, Build > Build APK(s).

## Permissions / what you allow on the phone
1. Display over other apps (button in app)
2. Screen capture dialog -> choose "Share one app" -> Free Fire
3. Notifications (foreground service notification with a Stop button)
4. Recommended: Settings > Apps > FF Enhance > Battery > Unrestricted

## Notes
- Needs Android 14+. Older versions would capture their own overlay (feedback loop).
- It is a visual enhancer, not true DLSS and not FPS boost.
- Shizuku hooks are not included in v1.
