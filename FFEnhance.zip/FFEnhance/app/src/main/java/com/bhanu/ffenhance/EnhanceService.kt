package com.bhanu.ffenhance

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Surface
import android.view.View
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min

class EnhanceService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var overlay: GLSurfaceView? = null
    private var renderer: EnhanceRenderer? = null
    private var wm: WindowManager? = null
    private var capW = 0
    private var capH = 0
    private var dpi = 0

    private val projCallback = object : MediaProjection.Callback() {
        override fun onStop() { main.post { stopSelf() } }

        // Android 14+: fires when the shared app goes to background / returns.
        override fun onCapturedContentVisibilityChanged(isVisible: Boolean) {
            main.post { overlay?.visibility = if (isVisible) View.VISIBLE else View.INVISIBLE }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY

        startForegroundNow()

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(projCallback, main)
        projection = p

        wm = getSystemService(WindowManager::class.java)
        val b = wm!!.maximumWindowMetrics.bounds
        capW = max(b.width(), b.height())   // games run landscape
        capH = min(b.width(), b.height())
        dpi = resources.displayMetrics.densityDpi

        addOverlay()
        running = true
        return START_NOT_STICKY
    }

    private fun addOverlay() {
        val r = EnhanceRenderer(capW, capH, onSurface = { surface -> main.post { attach(surface) } },
            requestRender = { overlay?.requestRender() })
        renderer = r

        val v = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            setEGLConfigChooser(8, 8, 8, 8, 0, 0)
            holder.setFormat(PixelFormat.TRANSLUCENT)
            setZOrderOnTop(true)
            setRenderer(r)
            renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        }
        overlay = v

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or      // touches pass through to the game
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        wm!!.addView(v, lp)
    }

    private fun attach(surface: Surface) {
        val existing = vd
        if (existing != null) { existing.surface = surface; return }
        vd = projection?.createVirtualDisplay(
            "ffenhance", capW, capH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            surface, null, main
        )
    }

    private fun startForegroundNow() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "FF Enhance", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, EnhanceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle("FF Enhance is running")
            .setContentText("Tap Stop to remove the overlay")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    override fun onDestroy() {
        running = false
        try { projection?.unregisterCallback(projCallback) } catch (_: Exception) {}
        vd?.release(); vd = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        overlay?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        overlay = null
        renderer?.release(); renderer = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.bhanu.ffenhance.STOP"
        private const val CH = "ffenhance"
        @Volatile var running = false
    }
}
