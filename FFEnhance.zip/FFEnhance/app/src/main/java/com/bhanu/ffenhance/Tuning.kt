package com.bhanu.ffenhance

/** Live-tunable values, read by the renderer every frame. */
object Tuning {
    @Volatile var sharp = 0.6f      // 0..1  adaptive sharpening strength
    @Volatile var contrast = 1.05f  // 0.8..1.3
    @Volatile var sat = 1.10f       // 0.8..1.5
}
