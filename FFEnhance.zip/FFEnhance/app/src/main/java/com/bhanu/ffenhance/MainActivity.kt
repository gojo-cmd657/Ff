package com.bhanu.ffenhance

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.os.Bundle

class MainActivity : Activity() {

    private val reqCapture = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
            setBackgroundColor(0xFF101418.toInt())
        }

        root.addView(text("FF Enhance", 26f, bold = true))
        root.addView(text(
            "Screen enhancer overlay (adaptive sharpen + contrast + saturation).\n\n" +
            "1. Grant overlay permission.\n" +
            "2. Open Free Fire first and leave it running.\n" +
            "3. Come back here, press Start, and in the system dialog choose " +
            "\"Share one app\" → Free Fire.\n\n" +
            "Needs Android 14 or newer.", 14f))

        root.addView(button("1. Allow draw over other apps") {
            if (Settings.canDrawOverlays(this)) toast("Already allowed")
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(button("2. Start") { start() })
        root.addView(button("Stop") {
            startService(Intent(this, EnhanceService::class.java).setAction(EnhanceService.ACTION_STOP))
        })

        root.addView(slider("Sharpness", Tuning.sharp, 0f, 1f) { Tuning.sharp = it })
        root.addView(slider("Contrast", Tuning.contrast, 0.8f, 1.3f) { Tuning.contrast = it })
        root.addView(slider("Saturation", Tuning.sat, 0.8f, 1.5f) { Tuning.sat = it })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun start() {
        if (Build.VERSION.SDK_INT < 34) {
            toast("Android 14+ required (needed to capture only the game, not the overlay itself)")
            return
        }
        if (!Settings.canDrawOverlays(this)) { toast("Allow overlay permission first"); return }
        if (EnhanceService.running) { toast("Already running"); return }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val intent = mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForUserChoice())
        startActivityForResult(intent, reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, EnhanceService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            toast("Started — switch to Free Fire")
            moveTaskToBack(true)
        } else if (requestCode == reqCapture) {
            toast("Capture permission denied")
        }
    }

    // ---- tiny UI helpers ----
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun text(s: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(0xFFE8EDF2.toInt())
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, 12, 0, 12)
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun slider(name: String, init: Float, lo: Float, hi: Float, set: (Float) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 24, 0, 0) }
        val label = text("$name: ${"%.2f".format(init)}", 14f)
        val sb = SeekBar(this).apply {
            max = 100
            progress = (((init - lo) / (hi - lo)) * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = lo + (hi - lo) * p / 100f
                    set(v)
                    label.text = "$name: ${"%.2f".format(v)}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.gravity = Gravity.START
        box.addView(label); box.addView(sb)
        return box
    }
}
