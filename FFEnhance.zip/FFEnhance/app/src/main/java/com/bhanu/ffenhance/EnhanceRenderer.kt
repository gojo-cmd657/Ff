package com.bhanu.ffenhance

import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Receives captured frames into an external-OES texture and draws them
 * full-screen through a CAS-style adaptive sharpen + contrast + saturation shader.
 */
class EnhanceRenderer(
    private val capW: Int,
    private val capH: Int,
    private val onSurface: (Surface) -> Unit,
    private val requestRender: () -> Unit
) : GLSurfaceView.Renderer {

    private var program = 0
    private var tex = 0
    private var st: SurfaceTexture? = null
    private val frameReady = AtomicBoolean(false)
    private var hasFrame = false
    private val texMat = FloatArray(16)

    private val verts = fb(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
    private val uvs = fb(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))

    private var aPos = 0; private var aTex = 0
    private var uMat = 0; private var uTex = 0; private var uTexel = 0
    private var uSharp = 0; private var uContrast = 0; private var uSat = 0

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        tex = ids[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        program = link(VERT, FRAG)
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aTex = GLES20.glGetAttribLocation(program, "aTex")
        uMat = GLES20.glGetUniformLocation(program, "uTexMatrix")
        uTex = GLES20.glGetUniformLocation(program, "uTex")
        uTexel = GLES20.glGetUniformLocation(program, "uTexel")
        uSharp = GLES20.glGetUniformLocation(program, "uSharp")
        uContrast = GLES20.glGetUniformLocation(program, "uContrast")
        uSat = GLES20.glGetUniformLocation(program, "uSat")

        st?.release()
        val t = SurfaceTexture(tex)
        t.setDefaultBufferSize(capW, capH)
        t.setOnFrameAvailableListener {
            frameReady.set(true)
            requestRender()
        }
        st = t
        hasFrame = false
        onSurface(Surface(t))
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val t = st ?: return
        if (frameReady.getAndSet(false)) {
            t.updateTexImage()
            t.getTransformMatrix(texMat)
            hasFrame = true
        }
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        if (!hasFrame) return

        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glUniformMatrix4fv(uMat, 1, false, texMat, 0)
        GLES20.glUniform2f(uTexel, 1f / capW, 1f / capH)
        GLES20.glUniform1f(uSharp, Tuning.sharp)
        GLES20.glUniform1f(uContrast, Tuning.contrast)
        GLES20.glUniform1f(uSat, Tuning.sat)

        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, verts)
        GLES20.glEnableVertexAttribArray(aTex)
        GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 0, uvs)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aTex)
    }

    fun release() {
        st?.release()
        st = null
    }

    private fun fb(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(a); position(0)
        }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Shader error: " + GLES20.glGetShaderInfoLog(s))
        return s
    }

    private fun link(v: String, f: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, v))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, f))
        GLES20.glLinkProgram(p)
        return p
    }

    companion object {
        private const val VERT = """
            attribute vec2 aPos;
            attribute vec2 aTex;
            uniform mat4 uTexMatrix;
            varying vec2 vTex;
            void main() {
                gl_Position = vec4(aPos, 0.0, 1.0);
                vTex = (uTexMatrix * vec4(aTex, 0.0, 1.0)).xy;
            }
        """

        // CAS-style adaptive sharpening (inspired by AMD FidelityFX CAS), then contrast + saturation.
        private const val FRAG = """
            #extension GL_OES_EGL_image_external : require
            precision highp float;
            varying vec2 vTex;
            uniform samplerExternalOES uTex;
            uniform vec2 uTexel;
            uniform float uSharp;
            uniform float uContrast;
            uniform float uSat;

            void main() {
                vec3 c = texture2D(uTex, vTex).rgb;
                vec3 n = texture2D(uTex, vTex + vec2(0.0, -uTexel.y)).rgb;
                vec3 s = texture2D(uTex, vTex + vec2(0.0,  uTexel.y)).rgb;
                vec3 e = texture2D(uTex, vTex + vec2( uTexel.x, 0.0)).rgb;
                vec3 w = texture2D(uTex, vTex + vec2(-uTexel.x, 0.0)).rgb;

                vec3 mn = min(min(min(n, s), min(e, w)), c);
                vec3 mx = max(max(max(n, s), max(e, w)), c);
                vec3 amp = sqrt(clamp(min(mn, 1.0 - mx) / max(mx, vec3(0.0001)), 0.0, 1.0));
                float peak = -1.0 / mix(8.0, 5.0, uSharp);
                vec3 k = amp * peak;
                vec3 res = (c + (n + s + e + w) * k) / (1.0 + 4.0 * k);

                res = (res - 0.5) * uContrast + 0.5;
                float l = dot(res, vec3(0.299, 0.587, 0.114));
                res = mix(vec3(l), res, uSat);
                gl_FragColor = vec4(clamp(res, 0.0, 1.0), 1.0);
            }
        """
    }
}
